//package agent;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.Scanner;

class Server implements Runnable{
	
	ServerSocket server;
	Agent a;
	private Boolean running = true;
	Socket s = null;
	
	
	public Server( Agent a) {
		this.a = a;
	}
	
	@Override
	public void run() {
		Random rand = new Random();
		while(!a.catched && AgentMain.sRunning) {
			server = createServer();
			try {
				//server.setSoTimeout(5000);
				server.setSoTimeout(AgentMain.t2);
				System.out.println("SERVER: Wait for connection "+ a.names[0]+"("+ a.agency+","+a.number+") with " + server.getLocalPort());
				s = server.accept();
				Scanner sc      = new Scanner(s.getInputStream(), "utf-8");
				PrintWriter pw  = new PrintWriter(s.getOutputStream());
				
				System.out.println("SERVER: Accept "+ a.names[0]+"("+ a.agency+","+a.number+") with "+ server.getLocalPort());
				
				try {
					pw.println("OK");
					pw.flush();
					String test=sc.nextLine();
				}catch (NoSuchElementException e) {run();}
				
				pw.println(sendName());// 1. A szerver elk�ldi az �lnevei k�z�l az egyiket v�letlenszer�en.
				pw.flush();
				
              	if(sc.nextInt() == a.agency){//2.Szerver fogadja
              		System.out.println("SERVER: The agency mached");
                  	pw.println("OK");//4.K�l�nben a szerver elk�ldi az OK sz�veget.
					pw.flush();
					
					String line1 = sc.nextLine();//random empty string
					while(!(line1.equals("OK") || line1.equals("???"))){
						line1 = sc.nextLine();
					}
					
              		if(line1.equals("OK")){
              			System.out.println("SERVER: The agency ua");
	                  pw.println(a.secrets.get(rand.nextInt(a.secrets.size())));//5.majd mindketten elk�ldenek egy-egy titkos sz�veget a m�siknak, amit ismernek
	                  pw.flush();
	                  System.out.println("SERVER: Send random secret");
	                  a.secrets.add(sc.nextLine());
					  a.secretBetray.add(false);
	                  System.out.println("SERVER: Get random secret");
	                  System.out.println("SERVER: No betray and close");
	                  close(s,sc,pw);//5. �s ezut�n bontj�k a kapcsolatot
                    }else {
                    	System.out.println("SERVER: The agency other");
						String line3 = sc.nextLine();
						int l3 = Integer.parseInt(line3); 
                    	if(l3 == a.number) {//Ha helyes a sorsz�m, elk�ldi az �ltala ismert titkok egyik�t.
                    		System.out.println("SERVER: The number is ok");
                    		pw.println(sendNewSecret());//6.2 Ha helyes a sorsz�m, elk�ldi az �ltala ismert titkok egyik�t
                    		pw.flush();
                    		System.out.println("SERVER: Send random secret betray");
                    	}else {
                    		System.out.println("SERVER: Number tipp is wrong, close");
                    		close(s,sc,pw);//6.1 A szerver azonnal bontja a kapcsolatot, ha t�ves a sorsz�m.
                    	}
                    }
					
                }else{
                	System.out.println("SERVER:The agency no mached");
                  	close(s,sc,pw);//3.Ha a kliens t�vedett, akkor a szerver bontja a kapcsolatot.
                }
				System.out.println("SERVER: Catched ending");
              	if(!a.secretBetray.contains(false)) {
					System.out.println("SERVER: catched ending");
              		a.catched = true;
              	}
              	
				
			} catch (SocketTimeoutException e) {
				System.out.println("SERVER: TimeOut "+ a.names[0]+"("+ a.agency+","+a.number+")");
				try {
						server.close();
						server=null;
				} catch (IOException eIO) {}
				catch (NullPointerException eNULL) {}
			} catch (IOException e) { }
			finally {
				try {
						s.close();
						s=null;
						
						server.close();
						server=null;
				} catch (IOException e) {}
				catch (NullPointerException e) {}
			}
			if(AgentMain.sRunning) {
				checkAllCatch();
				//run();
			}
		}
	}
	
	private void checkAllCatch() {
		boolean find = false;
		int i=0;
		if(a.agency == 1){
			while(!find && i<AgentMain.n) {
				find = !AgentMain.agents1.get(i).catched;
				i++;
			}
		}else{
			while(!find && i<AgentMain.m) {
				find = !AgentMain.agents2.get(i).catched;
				i++;
			}
		}
		if(!find) {
			AgentMain.cRunning = false;
			AgentMain.sRunning = false;
			if(a.agency == 1){
				System.out.println("Win 2 "+a.names[0]+"("+ a.agency+","+a.number+")");
			}else{
				System.out.println("Win 1 "+a.names[0]+"("+ a.agency+","+a.number+")");
			}
		}
		
	}

	public String sendName() {
		Random rand = new Random();
		return a.names[rand.nextInt(a.names.length)];
	}
	
	public ServerSocket createServer() {	
		
		Random rand = new Random();
		while(true) {
			try {
				synchronized (a) { 
					//a.port = rand.nextInt(20010-20000)+1+20000;
					a.port = rand.nextInt(20100-20000)+1+20000;
				}
				return new ServerSocket(a.port);
			}catch(IOException e) {continue;}
		}
	}
	
	
	private void close(Socket s, Scanner sc, PrintWriter pw) throws IOException {
		try{
			sc.close();
			pw.close();
			s.close();
			s=null;
		}catch(IOException e){}
		
	}
	
	private String sendNewSecret() {

		Random rand = new Random();
		int r=rand.nextInt(a.secrets.size());
			while(a.secretBetray.get(r)) {
				r=rand.nextInt(a.secrets.size());
			}
		a.secretBetray.set(r, true);
		return a.secrets.get(r);
		
	}
}