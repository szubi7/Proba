//package agent;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.*;

class Client implements Runnable{

	private Agent a;
	int p ;
	private Map<String,Integer> knowAgencys= new HashMap<>();
	private Map<String,Integer> knowNumbers= new HashMap<>();

	public Client(Agent a) {
		this.a = a;
	}
	
	
	
	@Override
	public void run() {
		while(AgentMain.cRunning && !a.catched) {
			boolean passAge = false;
			Random rand = new Random();
			Socket client = createClient();
			while(client == null && AgentMain.cRunning && !a.catched) {
				client = createClient();	
			}
			if(!(client != null)){
				break;
			}
			System.out.println("CLIENT: "+a.names[0]+"("+ a.agency+","+a.number+") connected with " + client.getPort());
			try {
				passAge = false;
				Scanner sc      = new Scanner(client.getInputStream(), "utf-8");
				PrintWriter pw  = new PrintWriter(client.getOutputStream());
				try {
					pw.println("OK");
					pw.flush();
					if(sc.hasNextLine()) {
						String line = sc.nextLine();
					}else {run();}
				}catch (NoSuchElementException e) {run();}
				String gettedName = sc.nextLine();//1. Client fogadja
				System.out.println("CLIENT: Getted name: "+ gettedName);
				int age=0;
				if(knowAgencys.containsKey(gettedName)) {//2.Erre a kliens elk�ldi azt, hogy szerinte a szerver melyik �gyn�ks�ghez tartozik.
					System.out.println("CLIENT: Know the name");
					pw.println(knowAgencys.get(gettedName));//2.Ha a kliens m�r tal�lkozott ezzel az �ln�vvel, akkor tudja a helyes v�laszt erre a k�rd�sre, �s azt k�ldi el
					pw.flush();
					System.out.println("CLIENT: Send the good agency");
					sc.nextLine();//getting OK
					passAge=true;
				}else {
					System.out.println("CLIENT: Don't know the name");
					age = rand.nextInt(2)+1;
					pw.println(age);//2.k�l�nben tippel
					pw.flush();
					System.out.println("CLIENT: Send the tipp agency");
					
					try {
						String line = sc.nextLine();//getting OK
						knowAgencys.put(gettedName, age);
						passAge=true;
					}catch(NoSuchElementException e) {//3.Ha a kliens t�vedett, akkor a szerver bontja a kapcsolatot.
						System.out.println("CLIENT: Agency is not ok");
						if(age==1) {
							knowAgencys.put(gettedName, 2);
						}else
							knowAgencys.put(gettedName, 1);
						close(client,sc,pw);
					}
				}
				int num = 0;
				if(passAge) {
					System.out.println("CLIENT: Agency is ok");
					if(a.agency == age) {//5.A kliens, ha azonos �gyn�ks�ghez tartozik, elk�ldi az OK sz�veget,
						System.out.println("CLIENT: Agency is same");
						pw.println("OK");
						pw.flush();
						pw.println(a.secrets.get(rand.nextInt(a.secrets.size())));
						pw.flush();
						System.out.println("CLIENT: Send random secret no betray");
						a.secrets.add(sc.nextLine());
						a.secretBetray.add(false);
						close(client,sc,pw);//5. �s ezut�n bontj�k a kapcsolatot
					}else {
						System.out.println("CLIENT: Agency is not same");
						pw.println("???");//6.A kliens, ha a m�sik �gyn�ks�ghez tartozik, elk�ldi a ??? sz�vege
						pw.flush();
						if(knowNumbers.containsKey(gettedName)) {//6. majd egy sz�mot, ami szerinte a m�sik �gyn�k sorsz�ma lehet.
							pw.println(knowAgencys.get(gettedName));
							pw.flush();
							System.out.println("CLIENT: Know the number");
						}else {
							System.out.println("CLIENT: Tipping a number");
							if(age == 1) {
								num = rand.nextInt(AgentMain.n)+1;
								pw.println(num);
								pw.flush();
							}else {
								num = rand.nextInt(AgentMain.m)+1;
								pw.println(num);
								pw.flush();
							}
						}
						try {
							String newSecret = sc.nextLine();
							System.out.println("CLIENT: Number is ok");
							a.newSecrets.add(newSecret);
							a.secrets.add(newSecret);
							a.secretBetray.add(false);
						}catch(NoSuchElementException e) {System.out.println("CLIENT: Number is not ok");}
					}
				}
				
			} catch (IOException e) {
				
		}catch (NoSuchElementException e){/*only after the winning*/}
			
			
			try {
				client.close();
				System.out.println("CLIENT: Close "+ a.names[0]+"("+ a.agency+","+a.number+")");
				client=null;
			} catch (IOException e) {
				
			}catch (NullPointerException ex){}
			
			if(AgentMain.cRunning) {
				checkAllSecret();
			}
		}	
	}
	
	private Socket createClient() {
		Random rand = new Random();
		//int p = rand.nextInt(20010-20000)+1+20000;
		int p = rand.nextInt(20100-20000)+1+20000;
		try {
			//Thread.sleep(rand.nextInt(200));
			Thread.sleep(rand.nextInt(AgentMain.t2-AgentMain.t1)+1+AgentMain.t1);
		} catch (InterruptedException e) {}
		synchronized(a) {
			if(p!=a.port) {
				try {
					return new Socket("localhost",p);
				}catch(IOException e) {
					return null;
				}
				catch (Exception e){ return null;}
				
			}else {
				return null;
			}
		}
	}
	
	private void close(Socket s, Scanner sc, PrintWriter pw) throws IOException {
		sc.close();
		pw.close();
		s.close();
		s=null;
		
	}
	
	public void checkAllSecret() {
		if(a.agency == 1) {
			if(a.newSecrets.size() == AgentMain.m) {
				AgentMain.cRunning = false;
				AgentMain.sRunning = false;
				System.out.println("Win 1 agency "+a.names[0]+"("+ a.agency+","+a.number+")");
			}
		}else {
			if(a.newSecrets.size() == AgentMain.n) {
				AgentMain.cRunning = false;
				AgentMain.sRunning = false;
				System.out.println("Win 2 agency "+a.names[0]+"("+ a.agency+","+a.number+")");
			}
		}
		
	}
	
}

